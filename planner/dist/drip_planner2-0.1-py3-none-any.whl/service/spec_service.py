class SpecService:

    def __init__(self, conf):
        self.configuration = conf

    def get_property(self, prop_key):
        return None
